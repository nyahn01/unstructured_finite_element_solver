"""
Test if FEniCS is properly installed.
"""

from fenics import *
import numpy as np

print("Fenics available")
