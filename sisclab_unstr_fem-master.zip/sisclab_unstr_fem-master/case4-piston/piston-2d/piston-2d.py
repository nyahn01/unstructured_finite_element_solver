"""
Heat equation in a 2d piston.

Objective: implement a problem with multiple complex and heterogeneous boundaries 
"""

