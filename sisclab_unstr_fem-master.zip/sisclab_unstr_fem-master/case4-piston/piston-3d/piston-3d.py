"""
Heat equation in a 3d piston.

Objective: implement a problem with multiple complex and heterogeneous boundaries 
"""

